import cv2
import mediapipe as mp
import numpy as np
import pickle
import time
import os
import sys
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.image import Image
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.clock import Clock
from kivy.graphics.texture import Texture
from kivy.core.window import Window
from plyer import tts
from kivy.animation import Animation
from kivy.graphics import Color, RoundedRectangle, Line
from kivy.metrics import dp

from kivy.utils import platform
import json
from kivy.uix.textinput import TextInput

# Helper function pour obtenir le chemin des fichiers sur Android
def get_file_path(filename):
    """Retourne le chemin absolu d'un fichier, compatible Android"""
    if platform == 'android':
        # Sur Android, les fichiers sont dans le répertoire de l'app
        from android import mActivity
        app_path = mActivity.getFilesDir().getPath()
        # Les fichiers sont copiés dans le dossier interne lors du build
        # On doit chercher dans le répertoire de l'application
        # Buildozer copie les fichiers dans le répertoire racine
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    else:
        # Sur PC, utiliser le chemin relatif normal
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)

class HandGestureApp(App):
    def build(self):
        if platform == 'android':
            from android.permissions import request_permissions, Permission
            request_permissions([Permission.CAMERA, Permission.RECORD_AUDIO])

        # Modern gradient background
        Window.clearcolor = (0.05, 0.05, 0.1, 1)  # Dark blue-black

        # Main Layout with modern spacing
        self.main_layout = BoxLayout(orientation='vertical', padding=dp(15), spacing=dp(12))

        # Camera Feed Container with rounded corners
        self.camera_container = FloatLayout(size_hint=(1, 0.55))
        self.image = Image(size_hint=(1, 1))
        self.camera_container.add_widget(self.image)
        
        # Animated detection overlay label (floats over camera)
        self.detection_label = Label(
            text="",
            font_size='48sp',
            bold=True,
            color=(0.2, 0.8, 1, 0),  # Cyan with 0 opacity initially
            size_hint=(None, None),
            pos_hint={'center_x': 0.5, 'center_y': 0.5}
        )
        self.camera_container.add_widget(self.detection_label)
        self.main_layout.add_widget(self.camera_container)

        # Modern Info Card with gradient effect
        self.info_card = BoxLayout(
            orientation='vertical',
            size_hint=(1, 0.18),
            spacing=dp(8),
            padding=dp(15)
        )
        
        # Add visual card background
        with self.info_card.canvas.before:
            Color(0.12, 0.15, 0.22, 1)  # Dark card background
            self.info_card_bg = RoundedRectangle(
                size=self.info_card.size,
                pos=self.info_card.pos,
                radius=[dp(15)]
            )
        self.info_card.bind(size=self._update_card_bg, pos=self._update_card_bg)
        
        # Modern Letters Label with custom font
        self.letters_label = Label(
            text="Détecté: ",
            font_size='18sp',
            color=(0.6, 0.8, 1, 1),  # Light blue
            bold=True,
            halign='left',
            valign='middle'
        )
        self.letters_label.bind(size=self.letters_label.setter('text_size'))
        self.info_card.add_widget(self.letters_label)
        
        # Modern Phrase Label with animation support
        self.phrase_label = Label(
            text="Phrase: ",
            font_size='22sp',
            color=(1, 1, 1, 1),
            bold=True,
            halign='center',
            valign='middle'
        )
        self.phrase_label.bind(size=self.phrase_label.setter('text_size'))
        self.info_card.add_widget(self.phrase_label)
        
        self.main_layout.add_widget(self.info_card)
        
        self.main_layout.add_widget(self.info_layout)

        # Modern Action Buttons with rounded style
        self.buttons_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, 0.12),
            spacing=dp(10)
        )
        
        self.clear_btn = self._create_modern_button(
            "🗑️ Effacer",
            (0.95, 0.27, 0.33, 1),  # Modern red
            self.clear_phrase
        )
        self.buttons_layout.add_widget(self.clear_btn)

        self.speak_btn = self._create_modern_button(
            "🔊 Parler",
            (0.26, 0.67, 0.45, 1),  # Modern green
            self.speak_phrase
        )
        self.buttons_layout.add_widget(self.speak_btn)

        self.delete_btn = self._create_modern_button(
            "⬅️ Retour",
            (0.95, 0.61, 0.27, 1),  # Modern orange
            self.delete_last_letter
        )
        self.buttons_layout.add_widget(self.delete_btn)

        self.space_btn = self._create_modern_button(
            "␣ Espace",
            (0.27, 0.54, 0.95, 1),  # Modern blue
            self.add_space
        )
        self.buttons_layout.add_widget(self.space_btn)
        
        self.main_layout.add_widget(self.buttons_layout)

        # Modern Language Selector
        self.lang_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, 0.08),
            spacing=dp(10)
        )
        
        self.btn_ar = self._create_lang_button(
            "🇦🇪 العربية",
            (0.5, 0.4, 0.85, 1),
            lambda x: self.change_language('ar')
        )
        self.lang_layout.add_widget(self.btn_ar)
        
        self.btn_fr = self._create_lang_button(
            "🇫🇷 FR",
            (0.4, 0.6, 0.95, 1),
            lambda x: self.change_language('fr')
        )
        self.lang_layout.add_widget(self.btn_fr)
        
        self.btn_en = self._create_lang_button(
            "🇬🇧 EN",
            (0.95, 0.5, 0.5, 1),
            lambda x: self.change_language('en')
        )
        self.lang_layout.add_widget(self.btn_en)
        
        self.main_layout.add_widget(self.lang_layout)
        
        # Modern ESP32 Connection Card
        self.esp_layout = BoxLayout(
            orientation='horizontal',
            size_hint=(1, 0.07),
            spacing=dp(8)
        )
        
        self.ip_input = TextInput(
            text='192.168.1.100',
            multiline=False,
            size_hint=(0.65, 1),
            font_size='16sp',
            background_color=(0.15, 0.18, 0.25, 1),
            foreground_color=(1, 1, 1, 1),
            cursor_color=(0.2, 0.8, 1, 1),
            padding=[dp(12), dp(8)]
        )
        self.esp_layout.add_widget(self.ip_input)
        
        self.cam_btn = self._create_modern_button(
            "📡 ESP32",
            (0.2, 0.7, 0.9, 1),
            self.connect_esp32,
            size_hint=(0.35, 1)
        )
        self.esp_layout.add_widget(self.cam_btn)
        self.main_layout.add_widget(self.esp_layout)

        # Initialize Logic
        self.init_logic()

        return self.main_layout
    
    def _update_card_bg(self, instance, value):
        """Update card background position and size"""
        self.info_card_bg.size = instance.size
        self.info_card_bg.pos = instance.pos
    
    def _create_modern_button(self, text, color, callback, size_hint=(0.25, 1)):
        """Create a modern styled button with rounded corners"""
        btn = Button(
            text=text,
            size_hint=size_hint,
            background_color=(0, 0, 0, 0),  # Transparent for custom bg
            font_size='15sp',
            bold=True,
            color=(1, 1, 1, 1)
        )
        
        # Custom rounded background
        with btn.canvas.before:
            Color(*color)
            btn.rect = RoundedRectangle(
                size=btn.size,
                pos=btn.pos,
                radius=[dp(12)]
            )
        
        btn.bind(size=lambda i, v: setattr(btn.rect, 'size', v))
        btn.bind(pos=lambda i, v: setattr(btn.rect, 'pos', v))
        btn.bind(on_press=callback)
        
        return btn
    
    def _create_lang_button(self, text, color, callback):
        """Create language selector button"""
        return self._create_modern_button(text, color, callback, size_hint=(0.33, 1))

    def init_logic(self):
        """Initialisation avec gestion d'erreurs robuste pour Android"""
        try:
            # Model
            print("[INFO] Chargement du modèle...")
            try:
                model_path = get_file_path('model.p')
                print(f"[INFO] Chemin du modèle: {model_path}")
                
                if not os.path.exists(model_path):
                    print(f"[ERROR] Fichier model.p introuvable: {model_path}")
                    self.model = None
                else:
                    with open(model_path, 'rb') as f:
                        model_dict = pickle.load(f)
                        self.model = model_dict['model']
                    print("[OK] Modèle chargé avec succès")
            except Exception as e:
                print(f"[ERROR] Erreur chargement modèle: {e}")
                self.model = None

            # MediaPipe
            print("[INFO] Initialisation MediaPipe...")
            try:
                self.mp_hands = mp.solutions.hands
                self.mp_drawing = mp.solutions.drawing_utils
                self.mp_drawing_styles = mp.solutions.drawing_styles
                self.hands = self.mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.3)
                print("[OK] MediaPipe initialisé")
            except Exception as e:
                print(f"[ERROR] Erreur MediaPipe: {e}")
                self.hands = None

            # Labels
            self.labels_dict = {
                0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'Demandes', 5: 'Destinations',
                6: 'E', 7: 'F', 8: 'Famille', 9: 'G', 10: 'H', 11: 'I', 12: 'J',
                13: 'Jours', 14: 'K', 15: 'L', 16: 'M', 17: 'N', 18: 'O', 19: 'P',
                20: 'Q', 21: 'R', 22: 'S', 23: 'T', 24: 'Transport', 25: 'U',
                26: 'V', 27: 'W', 28: 'X', 29: 'Y', 30: 'Z'
            }
            
            # State variables
            self.detected_letters = []
            self.phrase_text = ""
            self.phrase_keys = []  # Pour traduction
            self.last_time_letter_added = time.time()
            self.correction_dict = {'H': ['B', 'G'], 'J': ['I']}
            self.using_esp32 = False
            self.esp32_url = ""
            
            # Charger traductions
            print("[INFO] Chargement des traductions...")
            self.current_lang = 'fr'
            self.load_translations()

            # Camera initialization
            print("[INFO] Initialisation de la caméra...")
            try:
                self.capture = self._init_camera()
                if self.capture and self.capture.isOpened():
                    print("[OK] Caméra initialisée avec succès")
                    Clock.schedule_interval(self.update, 1.0 / 30.0) # 30 FPS
                else:
                    print("[WARNING] Caméra non disponible, mode ESP32 seulement")
                    self.capture = None
            except Exception as e:
                print(f"[ERROR] Erreur initialisation caméra: {e}")
                self.capture = None
                
            print("[OK] Initialisation terminée")
            
        except Exception as e:
            print(f"[CRITICAL ERROR] Erreur lors de init_logic: {e}")
            import traceback
            traceback.print_exc()
    
    def _init_camera(self):
        """Initialise la caméra avec backends adaptés à la plateforme"""
        print(f"[INFO] Plateforme détectée: {platform}")
        
        try:
            if platform == 'android':
                # Sur Android, utiliser l'index simple sans backend spécifique
                print("[INFO] Initialisation caméra Android...")
                
                # Essayer les deux caméras (0 = arrière, 1 = avant)
                for index in [0, 1]:
                    print(f"[INFO] Test caméra index {index}...")
                    cap = cv2.VideoCapture(index)
                    
                    if cap.isOpened():
                        # Test rapide
                        ret, frame = cap.read()
                        if ret and frame is not None:
                            print(f"[OK] Caméra {index} fonctionne")
                            return cap
                        cap.release()
                
                print("[WARNING] Aucune caméra Android trouvée")
                return None
                
            else:
                # Sur PC (Windows/Linux/Mac)
                print("[INFO] Initialisation caméra PC...")
                backends = [
                    ("MSMF", cv2.CAP_MSMF),    # Windows 10/11
                    ("DSHOW", cv2.CAP_DSHOW),   # Windows alternatif
                    ("V4L2", cv2.CAP_V4L2),     # Linux
                    ("ANY", cv2.CAP_ANY)        # Fallback
                ]
                
                for name, backend in backends:
                    for index in range(2):
                        try:
                            print(f"[INFO] Test camera index={index}, backend={name}...")
                            cap = cv2.VideoCapture(index, backend)
                            
                            if cap.isOpened():
                                time.sleep(0.3)
                                ret, frame = cap.read()
                                if ret and frame is not None:
                                    print(f"[OK] Caméra trouvée: {name} index {index}")
                                    return cap
                                cap.release()
                        except Exception as e:
                            print(f"[WARNING] Backend {name} échoué: {e}")
                            continue
                
                print("[WARNING] Aucune caméra PC trouvée")
                return None
                
        except Exception as e:
            print(f"[ERROR] Exception dans _init_camera: {e}")
            import traceback
            traceback.print_exc()
            return None

    def connect_esp32(self, instance):
        ip = self.ip_input.text.strip()
        if not ip:
            return
        
        # Format typical for ESP32-CAM stream server provided
        url = f"http://{ip}:81/stream"
        print(f"Tentative de connexion à l'ESP32: {url}")
        
        # Tester la connexion
        new_cap = cv2.VideoCapture(url)
        if new_cap.isOpened():
            ret, frame = new_cap.read()
            if ret:
                if self.capture:
                    self.capture.release()
                self.capture = new_cap
                self.using_esp32 = True
                self.cam_btn.text = "ESP32 Connecté"
                self.cam_btn.background_color = (0.2, 0.8, 0.2, 1)
                print("✓ Connexion ESP32 réussie!")
            else:
                print("❌ Impossible de lire le flux ESP32")
                new_cap.release()
        else:
            print("❌ Impossible d'ouvrir l'URL ESP32")


    def update(self, dt):
        """Mise à jour du flux vidéo avec gestion d'erreurs robuste"""
        try:
            # Vérifier que la caméra existe
            if not self.capture:
                return
                
            # Anti-blocage: compteur d'erreurs
            if not hasattr(self, '_consecutive_errors'):
                self._consecutive_errors = 0
                
            ret, frame = self.capture.read()
            if not ret or frame is None:
                self._consecutive_errors += 1
                if self._consecutive_errors >= 30:  # ~1 seconde d'erreurs
                    print("[WARNING] Trop d'erreurs caméra, tentative reconnexion...")
                    try:
                        self.capture.release()
                        time.sleep(1)
                        self.capture = self._init_camera()
                        self._consecutive_errors = 0
                    except:
                        pass
                return
            
            # Réinitialiser le compteur si lecture réussie
            self._consecutive_errors = 0
        except Exception as e:
            print(f"[ERROR] Exception dans update: {e}")
            return

        H, W, _ = frame.shape
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        
        # MediaPipe Processing
        data_aux = []
        x_ = []
        y_ = []
        self.detected_letters = [] # Reset for this frame
        
        results = self.hands.process(frame_rgb)
        
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                self.mp_drawing.draw_landmarks(
                    frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS,
                    self.mp_drawing_styles.get_default_hand_landmarks_style(),
                    self.mp_drawing_styles.get_default_hand_connections_style())

            # Prediction Logic (Same as original)
            for hand_landmarks in results.multi_hand_landmarks:
                for i in range(len(hand_landmarks.landmark)):
                    x = hand_landmarks.landmark[i].x
                    y = hand_landmarks.landmark[i].y
                    x_.append(x)
                    y_.append(y)

                for i in range(len(hand_landmarks.landmark)):
                    x = hand_landmarks.landmark[i].x
                    y = hand_landmarks.landmark[i].y
                    data_aux.append(x - min(x_))
                    data_aux.append(y - min(y_))
            
            # Pad or truncate data_aux to expected 42 features
            # NOTE: Simple fix to match inference shape expectations if user hasn't fully fixed dataset yet
            # But relying on correct dataset is better.
            if len(data_aux) == 42:
                try:
                    prediction = self.model.predict([np.asarray(data_aux)])
                    predicted_character = self.labels_dict[int(prediction[0])]
                    self.detected_letters.append(predicted_character)
                except Exception as e:
                    print(f"Prediction error: {e}")

            # Modern UI with gradient box and animated text
            x1 = int(min(x_) * W) - 10
            y1 = int(min(y_) * H) - 10
            x2 = int(max(x_) * W) - 10
            y2 = int(max(y_) * H) - 10

            # Draw modern detection box with glow effect
            # Outer glow
            cv2.rectangle(frame, (x1-3, y1-3), (x2+3, y2+3), (50, 200, 255), 2)
            # Main rectangle with cyan color
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 255), 3)
            
            if self.detected_letters:
                detected_char = self.detected_letters[0]
                
                # Trigger animated overlay
                self.animate_detected_letter(detected_char)
                
                # Draw on video with modern style
                # Background for text
                text_size = cv2.getTextSize(detected_char, cv2.FONT_HERSHEY_SIMPLEX, 1.8, 4)[0]
                cv2.rectangle(frame, (x1, y1 - text_size[1] - 20), 
                             (x1 + text_size[0] + 10, y1 - 5), (0, 200, 255), -1)
                # Text with shadow
                cv2.putText(frame, detected_char, (x1 + 5, y1 - 10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1.8, (255, 255, 255), 4, cv2.LINE_AA)

            # Build Phrase
            self.build_phrase(self.detected_letters)


        # Update Kivy Image
        buf1 = cv2.flip(frame, 0)
        buf = buf1.tostring()
        image_texture = Texture.create(size=(frame.shape[1], frame.shape[0]), colorfmt='bgr')
        image_texture.blit_buffer(buf, colorfmt='bgr', bufferfmt='ubyte')
        self.image.texture = image_texture
        
        # Update Labels with modern format and animation
        if self.detected_letters:
            # Animate letters label update
            detected_text = "✨ Détecté: " + " → ".join(self.detected_letters[-3:])  # Show last 3
            if self.letters_label.text != detected_text:
                self.letters_label.text = detected_text
                # Quick pulse animation
                anim = Animation(font_size='20sp', duration=0.1) + Animation(font_size='18sp', duration=0.1)
                anim.start(self.letters_label)
        else:
            self.letters_label.text = "✨ Détecté: (en attente...)"


    def animate_detected_letter(self, letter):
        """Animate the detected letter overlay with smooth effects"""
        # Update text
        self.detection_label.text = letter
        self.detection_label.size = self.detection_label.texture_size
        
        # Reset and create smooth animation sequence
        self.detection_label.opacity = 0
        self.detection_label.font_size = '36sp'
        
        # Fade in + scale up
        anim1 = Animation(
            opacity=1,
            font_size='64sp',
            duration=0.3,
            t='out_cubic'
        )
        
        # Hold
        anim2 = Animation(duration=0.8)
        
        # Fade out + scale down
        anim3 = Animation(
            opacity=0,
            font_size='48sp',
            duration=0.4,
            t='in_cubic'
        )
        
        # Chain animations
        anim_sequence = anim1 + anim2 + anim3
        anim_sequence.start(self.detection_label)
    
    def load_translations(self):
        try:
            trans_path = get_file_path('translations.json')
            print(f"[INFO] Chargement traductions: {trans_path}")
            
            if not os.path.exists(trans_path):
                print(f"[WARNING] Fichier translations.json introuvable")
                self.translations = {}
                return
                
            with open(trans_path, 'r', encoding='utf-8') as f:
                self.translations = json.load(f)
            print(f"[OK] {len(self.translations)} traductions chargées")
        except Exception as e:
            print(f"[ERROR] Erreur chargement traductions: {e}")
            import traceback
            traceback.print_exc()
            self.translations = {}
    
    def translate(self, key):
        if key in self.translations:
            return self.translations[key].get(self.current_lang, key)
        return key
    
    def change_language(self, lang):
        self.current_lang = lang
        # Retraduire la phrase
        translated_text = ' '.join([self.translate(key) for key in self.phrase_keys])
        self.phrase_text = translated_text
        self.phrase_label.text = "Phrase: " + self.phrase_text

    def build_phrase(self, detected_letters):
        current_time = time.time()
        if not detected_letters:
            return

        if current_time - self.last_time_letter_added >= 2:
            for i, letter in enumerate(detected_letters):
                corrected_letter = self.autocorrect_letter(letter)
                self.phrase_keys.append(corrected_letter)
                self.phrase_text += self.translate(corrected_letter) + ' '
            self.last_time_letter_added = current_time
            self.phrase_label.text = "Phrase: " + self.phrase_text

    def autocorrect_letter(self, letter):
        if letter in self.correction_dict:
            possible_corrections = self.correction_dict[letter]
            most_common_correction = max(set(possible_corrections), key=possible_corrections.count)
            return most_common_correction
        else:
            return letter

    def clear_phrase(self, instance):
        self.phrase_text = ""
        self.phrase_keys = []
        self.phrase_label.text = "Phrase: "
    
    def delete_last_letter(self, instance):
        if self.phrase_keys:
            self.phrase_keys.pop()
            translated_text = ' '.join([self.translate(key) for key in self.phrase_keys])
            self.phrase_text = translated_text
            self.phrase_label.text = "Phrase: " + self.phrase_text

    def add_space(self, instance):
        self.phrase_text += " "
        self.phrase_label.text = "Phrase: " + self.phrase_text

    def speak_phrase(self, instance):
        if not self.phrase_text or self.phrase_text.strip() == "":
            print("No phrase to speak")
            return
            
        try:
            tts.speak(self.phrase_text)
        except NotImplementedError:
            # Fallback purely for PC testing if plyer tts fails
            try:
                import pyttsx3
                engine = pyttsx3.init()
                engine.say(self.phrase_text)
                engine.runAndWait()
            except:
                print("TTS not supported")

    def on_stop(self):
        self.capture.release()

if __name__ == '__main__':
    HandGestureApp().run()
